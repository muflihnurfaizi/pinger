# Pinger CLI

Pinger CLI is a command-line tool that pings specified IP addresses and sends their status (online/offline) via MQTT. It is ideal for monitoring network devices and integrating status reporting into your automation workflows.

## Features

- **Ping Devices:** Checks whether devices are online by pinging their IP addresses.
- **MQTT Reporting:** Publishes a JSON-formatted status report to a specified MQTT broker.
- **Scheduling:** Supports scheduled pings at specified times.
- **Manual Trigger:** Listens for MQTT trigger messages to immediately generate a status report.
- **Rich CLI Output:** Uses [Click](https://click.palletsprojects.com/) and [Rich](https://rich.readthedocs.io/) for a polished command-line experience.

## Installation

### Requirements

- Python 3.8 or higher
- [Poetry](https://python-poetry.org/) (for dependency management and packaging)

### Steps

1. **Clone the repository:**

   ```bash
   git clone https://github.com/your-username/your-repo.git
   cd your-repo

	2.	Install dependencies using Poetry:

poetry install



Usage

The CLI entry point is called pinger. You can run the application with:

pinger --config config.json

	•	The --config option specifies the path to your configuration file (default is config.json).

Configuration

Create a config.json file in your project directory with a structure similar to the following:

{
  "ied_list": [
    {
      "substation": "Substation A",
      "bay": "Bay 1",
      "ied": "IED1",
      "ip": "192.168.1.10",
      "source_ip": "192.168.1.1"
    }
  ],
  "mqtt": {
    "broker": "mqtt.example.com",
    "port": 1883,
    "report_topic": "pinger/report",
    "trigger_topic": "pinger/trigger"
  },
  "schedule_times": [
    "08:00:00",
    "12:00:00",
    "16:00:00"
  ]
}

	•	ied_list: An array of devices with details such as IP, source IP, and identifiers.
	•	mqtt: MQTT broker configuration including the broker address, port, and topics for reports and manual triggers.
	•	schedule_times: A list of times (in HH:MM:SS format) when the app will automatically generate a status report.

How It Works
	1.	Load Configuration: The app loads settings from the specified configuration file.
	2.	Ping Devices: At scheduled times (or when triggered via MQTT), it pings each device using the provided source IP.
	3.	Generate Report: A JSON report is generated detailing whether each device is online or offline.
	4.	Send via MQTT: The report is published to the MQTT broker on the configured topic.
	5.	Manual Trigger: The app subscribes to a trigger topic and will generate a report if it receives a trigger message.

Dependencies

The following dependencies are required:
	•	Click
	•	Rich
	•	rich-click
	•	paho-mqtt
	•	schedule

These are specified in the pyproject.toml file and will be installed when you run poetry install.

Packaging

To expose the pinger command, add the following entry point in your pyproject.toml:

[tool.poetry.scripts]
pinger = "your_package_name.pinger:cli"

Replace your_package_name.pinger with the correct module path for your project.

Contributing

Contributions are welcome! Feel free to open issues or submit pull requests with improvements.

License

This project is licensed under the MIT License.